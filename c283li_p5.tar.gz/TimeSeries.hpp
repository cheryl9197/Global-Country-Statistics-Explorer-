// define class and declare functions for TimeSeries

#ifndef TIMESERIES_HPP
#define TIMESERIES_HPP
#include <iostream>
#include <string>

class TimeSeries {

    public:
        TimeSeries (); //constructore
        ~TimeSeries (); //destructor
        TimeSeries(const TimeSeries& other); //copy constructor       
        TimeSeries& operator=(const TimeSeries& other); //copy assignment operator
        //required functions
        bool load (std::string filename); 
        bool print ();
        bool add (int Y, double D);
        bool update (int Y, double D);
        double mean ();
        bool is_monotonic ();
        bool best_fit (double &m, double &b);
        //helper functions
        int getsize();
        std::string getCode() const; 
        std::string getSeriesName ();
        int getcapacity(); 
        void setSeriesName (std::string name);
        void setSeriesCode (std::string code);

    private:
        int size;
        int capacity;
        std::string seriesname;
        std::string seriescode;
        int* yearArray;
        double* dataArray;
       
};

#endif