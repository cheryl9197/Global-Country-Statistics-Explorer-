#include <iostream>
#include <sstream>
#include <fstream>
#include "TimeSeries.hpp"
#include "CountryData.hpp"
#include "Tree.hpp"
#include <cmath>

// treenode constructor
Tree::TreeNode::TreeNode (double leftval, double rightval, int initialcap) {

    L = leftval;
    R = rightval;
    treecount = 0;
    treecapacity = initialcap;
    countryIndices = new int[treecapacity];
    left = nullptr;
    right = nullptr;
}

// treenode destructor
Tree::TreeNode::~TreeNode() {
    delete [] countryIndices; 
}

// tree constructor
Tree::Tree() {
    root = nullptr;
}

// tree destructor
Tree::~Tree() {
    deleteTree(root);
}

// recursively delete all nodes in the tree using post-order traversal
// post-order is necessary here because deleting a parent before its children
// would lose access to those children, causing memory leaks
void Tree::deleteTree (TreeNode* node) {

    if (node != nullptr) {

        deleteTree(node->left);
        deleteTree(node->right);
        delete node;
    }
}

// builds the binary tree with only countries that have a valid mean for the given 
// series code, then using helper buildNode
// pre-filtering invalid means avoids filling the tree with unusable data
bool Tree::build_p3 (CountryData countries[], int countryCount, std::string seriescode) {

    currentSeriesCode = seriescode;
    currentCountryCount = countryCount; 
    
    // if a tree already exists, destroy it before building a new one
    // this prevents memory leaks when build is called multiple times
    if (root != nullptr) {

        deleteTree(root);
        root = nullptr;
    }

    int indices [512];
    double means [512];
    int count = 0;

    // collect only countries that have this series and a valid (not -1) mean
    // storing both the index and mean together avoids repeated lookups later
    for (int i = 0; i < countryCount; ++i) {

        int seriesIndex = countries[i].getSeriesIndex(seriescode);

        if (seriesIndex != -1) {

            double seriesMean = countries[i].getSeriesMean(seriesIndex);

            if (seriesMean != -1) {

                indices[count] = i;
                means[count] = seriesMean; 
                count++;
            }
        }
    }

    // compute the global min and max to pass as initial L/R bounds to buildNode
    // these bounds define the full range of the data at the root level
    double min = means[0];
    double max = means[0];

    for (int i = 0; i < count; i++) {

        if (means[i] > max) { 

            max = means[i];
        }

        if (means[i] < min) {

            min = means[i];
        }
    }

    globalMin = min;
    globalMax = max;

    root = buildNode(indices, means, count, min, max);

    return true;
}

// recursively builds a binary search tree where each node stores all country indices
// in its range, and splits them by the midpoint of the tight data range
// tight L/R bounds are computed first so midpoint reflects actual data at each level
Tree::TreeNode* Tree::buildNode(int indices[], double means[], int count, double L, double R) {

    TreeNode* node = new TreeNode(L, R, count);

    // copy all indices into this node so every ancestor holds a record of its descendants
    // this allows any node (not just leaves) to be queried if needed
    for (int i = 0; i < count; ++i) {

        node->countryIndices[i] = indices[i];
    }
    node->treecount = count;

    // compute tight L/R from actual data first so midpoint reflects real data range
    // this ensures the tree splits finely enough for limits_p3 to isolate the min/max
    node->L = means[0];
    node->R = means[0];

    for (int i = 1; i < count; ++i) {

        if (means[i] < node->L) {

            node->L = means[i];
        }

        if (means[i] > node->R) {

            node->R = means[i];
        }
    }

    // base case: one country cannot be split further
    if (count == 1) {

        return node;
    }

    // if all means are identical, splitting would cause infinite recursion
    // since every country would go to the same side every time
    bool identical = true;

    for (int i = 1; i < count; ++i) {

        if (fabs(means[i] - means[0]) > 1e-3) {

            identical = false;
            break;
        }
    }

    if (identical) {

        return node;
    }

    // use tight L/R for midpoint so splits are fine enough to isolate countries
    double midpoint = (node->L + node->R) / 2.0;
    node->midpoint = midpoint;

    int leftIndices[512], rightIndices[512];
    double leftMeans[512], rightMeans[512];
    int leftCount = 0, rightCount = 0;

    // spec requires strictly less than midpoint goes left
    // greater than or equal to midpoint goes right
    for (int i = 0; i < count; ++i) {

        if (means[i] < midpoint) {

            leftIndices[leftCount] = indices[i];
            leftMeans[leftCount] = means[i];
            leftCount++;
        } else {

            rightIndices[rightCount] = indices[i];
            rightMeans[rightCount] = means[i];
            rightCount++;
        }
    }

    // if all countries ended up on one side, further splitting is impossible
    // returning here avoids infinite recursion where the same split repeats forever
    if (leftCount == 0 || rightCount == 0) {

        return node;
    }

    node->left  = buildNode(leftIndices,  leftMeans,  leftCount,  node->L, midpoint);
    node->right = buildNode(rightIndices, rightMeans, rightCount, midpoint, node->R);

    return node;
}


// validates tree exists then uses findHelper
// helper cleans and ensures exactly one newline regardless of how many results are found
bool Tree::find_p3 (CountryData countries[], double mean, std::string operation) {

    if (root == nullptr) {

        std::cout << "failure" << std::endl;
        return false;
    }

    findHelper(root, countries, mean, operation);
    std::cout << std::endl;
    return true;
}

// recursively searches the tree for countries satisfying the operation
// uses L/R bounds at each node to pruen entire subtrees that cannot contain matches
// this avoids visiting every country and makes the search efficient
void Tree::findHelper(TreeNode* node, CountryData countries[], double mean, std::string operation) {
    
    if (node == nullptr) {
        return;
    }

    // for "less": if even the smallest value in this subtree (L) is >= mean, nothing qualifies
    // for "greater": if even the largest value (R) is <= mean, nothing qualifies
    // for "equal": if mean falls outside [L, R], no match can exist here
    if (operation == "less" && node->L >= mean) {
        return;
    }

    if (operation == "greater" && node->R <= mean) {
        return;
    }

    if (operation == "equal" && (mean < node->L - 1e-3 || mean > node->R + 1e-3)) {
        return;
    }

    // only print at leaf nodes to avoid printing the same country multiple times
    if (node->left == nullptr && node->right == nullptr) {

        for (int i = 0; i < node->treecount; ++i) {

            int index  = node->countryIndices[i];
            int sIndex = countries[index].getSeriesIndex(currentSeriesCode);

            if (sIndex != -1) {

                double m = countries[index].getSeriesMean(sIndex);

                // re-check the condition at the leaf level since it's approximate
                // a node's L/R range may include the value even if only some countries qualify
                if (m != -1) {

                    if ((operation == "less" && m < mean) || (operation == "greater" && m > mean) || (operation == "equal" && fabs(m - mean) <= 1e-3)) {

                        std::cout << countries[index].getCountryName() << " ";
                    }
                }
            }
        }
        return;
    }

    findHelper(node->left,  countries, mean, operation);
    findHelper(node->right, countries, mean, operation);
}

// searches for the country by name to get its index, then removes it from every
// node in the tree with it using deleteHelper
// the country must be removed from all nodes since internal nodes also store indices
bool Tree::delete_p3 (CountryData countries[], std::string countryname) {

    if (root == nullptr) {

        std::cout << "failure" << std::endl;
        return false;
    }

    int countryIndex = -1;

    // linear search is necessary here since countries are not indexed by name
    for (int i = 0; i < currentCountryCount; i++) {   

        if (countries[i].getCountryName() == countryname) {

            countryIndex = i;
            break;
        }      
    }

    if (countryIndex == -1) {

        std::cout << "failure" << std::endl;
        return false;
    }

    bool removed = deleteHelper(root, countryIndex);

    if (!removed) {

        std::cout << "failure" << std::endl;
        return false;
    }

    std::cout << "success" << std::endl;
    return true;
}

// recursively removes a country index from every node that contains it
// since every ancestor stores its descendants' indices, deletion must touch all nodes
// after removal, leaf nodes that become empty are deleted to keep the tree clean
bool Tree::deleteHelper(TreeNode*& node, int countryIndex) {

    if (node == nullptr) {

        return false;
    }

    bool found = false;

    // scan and shift to remove the index without leaving gaps in the array
    // decrementing i after removal ensures the element that shifted into position i isn't skipped
    for (int i = 0; i < node->treecount; ++i) {

        if (node->countryIndices[i] == countryIndex) {

            found = true;

            for (int j = i; j < node->treecount - 1; j++) {

                node->countryIndices[j] = node->countryIndices[j+1];
            }

        node->treecount--;
        i--;
        }
    }

    bool leftFound = deleteHelper(node->left, countryIndex);
    bool rightFound = deleteHelper(node->right, countryIndex);

    found = found || leftFound || rightFound;

    // delete empty leaf nodes after deletion to keep the tree structure valid
    // only remove leaves since removing internal nodes would disconnect their subtrees
    if (node->treecount == 0 && node->left == nullptr && node->right == nullptr) {
        
        delete node;
        node = nullptr;
    }

    return found;
}

// finds the country with the lowest or highest series mean by traversing
// to the leftmost or rightmost leaf respectively
// uses stored midpoint at each node to follow the exact same path as buildNode
bool Tree::limits_p3(CountryData countries[], std::string condition) {

    if (root == nullptr) {

        std::cout << "failure" << std::endl;
        return false;
    }

    TreeNode* node = root;

    // keep going left to find the minimum since spec places strictly less than midpoint on left
    if (condition == "lowest") {

        while (node->left != nullptr) {

            node = node->left;
        }

    // keep going right to find the maximum since spec places >= midpoint on right
    } else if (condition == "highest") {

        while (node->right != nullptr) {

            node = node->right;
        }

    } else {

        std::cout << "failure" << std::endl;
        return false;
    }

    for (int i = 0; i < node->treecount; ++i) {

        int index = node->countryIndices[i];
        std::cout << countries[index].getCountryName() << " ";
    }

    std::cout << std::endl;
    return true;
}

// traces the path from root to the leaf containing the given country
// prints L and R at each node to show how the tree narrows the range
// uses stored midpoint at each node to follow the exact same path as buildNode
bool Tree::trace_p3 (CountryData countries[], std::string countryname) {

    if (root == nullptr) {

        std::cout << "failure" << std::endl;
        return false;
    }

    int countryIndex = -1;

    // linear search needed since the tree is ordered by mean value, not by name
    for (int i = 0; i < currentCountryCount; i++) {

        if (countries[i].getCountryName() == countryname) {

            countryIndex = i;
            break;
        }
    }

    if (countryIndex == -1) {

        std::cout << "failure" << std::endl;
        return false;
    }

    int s = countries[countryIndex].getSeriesIndex(currentSeriesCode);

    if (s == -1) {

        std::cout << "failure" << std::endl;
        return false;
    }

    double mean = countries[countryIndex].getSeriesMean(s);

    TreeNode* node = root;

    while (node != nullptr) {

        std::cout << node->L << " " << node->R;

        if (node->left == nullptr && node->right == nullptr) {

            break;
        }

        std::cout << " ";

        // use stored midpoint to follow the exact same path buildNode used when inserting
        // this avoids recomputing the midpoint which could differ due to tight L/R bounds
        if (mean < node->midpoint && node->left != nullptr) {

            node = node->left;

        } else if (node->right != nullptr) {

            node = node->right;

        } else {

            break;
        }
    }

    std::cout << std::endl;
    return true;
}

// same as delete_p3 but without any output
// used by REMOVE_P4 which is responsible for printing its own success/failure
bool Tree::silent_delete(CountryData countries[], std::string countryname) {

    if (root == nullptr) {

        return false;
    }

    int countryIndex = -1;

    // linear search is necessary here since countries are not indexed by name
    for (int i = 0; i < currentCountryCount; i++) {

        if (countries[i].getCountryName() == countryname) {

            countryIndex = i;
            break;
        }
    }

    if (countryIndex == -1) {

        return false;
    }

    return deleteHelper(root, countryIndex);
}