#ifndef TREE_HPP
#define TREE_HPP
#include <iostream>
#include <string>
#include "CountryData.hpp"

class Tree {

    private:
        class TreeNode {

            public:

                TreeNode(double leftval, double rightval, int initialcap);
                ~TreeNode();

                double L;            // tight lower bound of means in this subtree
                double R;            // tight upper bound of means in this subtree
                double midpoint;     // stored so trace can follow the exact same path as buildNode

                int* countryIndices; // dynamically allocated array of country indices
                int treecount;       // number of countries currently in this node
                int treecapacity;    // capacity of countryIndices array

                TreeNode* left;
                TreeNode* right;
        };

        TreeNode* root;

        // stored so recursive helpers can access series data 
        std::string currentSeriesCode;
        int currentCountryCount;
        double globalMin;
        double globalMax;

        // private recursive helpers
        void deleteTree(TreeNode* node);
        TreeNode* buildNode(int indices[], double means[], int count, double L, double R);
        void findHelper(TreeNode* node, CountryData countries[], double mean, std::string operation);
        bool deleteHelper(TreeNode*& node, int countryIndex);

    public:

        Tree();
        ~Tree();

        // member functions
        bool build_p3(CountryData countries[], int countryCount, std::string seriescode);
        bool find_p3(CountryData countries[], double mean, std::string operation);
        bool delete_p3(CountryData countries[], std::string countryname);
        bool limits_p3(CountryData countries[], std::string condition);
        bool trace_p3(CountryData countries[], std::string countryname);
        bool silent_delete(CountryData countries[], std::string countryname); // for project 4
};

#endif